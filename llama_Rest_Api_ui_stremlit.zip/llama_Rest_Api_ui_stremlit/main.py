import streamlit as st
import requests

# Set up the API endpoint
api_url = "http://10.0.0.83:5000/api/chatbot/"

# Initialize or load the conversation history
if 'history' not in st.session_state:
    st.session_state['history'] = []

# Streamlit app title
st.header("AI-Powered Assistant for Any Question")

# Input field for the query
query = st.text_input("Enter your query:")

# Button to send the query
if st.button("Get Response"):
    if query:
        # Send the query to the REST API
        response = requests.post(api_url, json={"query": query})
        if response.status_code == 200:
            # Get the response from the API
            response_text = response.json().get("response")

            # Save the query and response to the history
            st.session_state['history'].append({"query": query, "response": response_text})

            # Display the response
            st.write("Response:", response_text)
        else:
            st.write("Error:", response.status_code)
    else:
        st.write("Please enter a query.")

# Display conversation history on the left side (sidebar)
st.sidebar.title("Conversation History")
for i, entry in enumerate(st.session_state['history']):
    # Shorten the response if it is too long
    short_response = entry['response'][:30] + "..." if len(entry['response']) > 30 else entry['response']

    # Use an expander to show the full response on click
    with st.sidebar.expander(f"Q{i + 1}: {entry['query']}"):
        st.write("Short Response:", short_response)
        st.write("Full Response:")
        st.write(entry['response'])
